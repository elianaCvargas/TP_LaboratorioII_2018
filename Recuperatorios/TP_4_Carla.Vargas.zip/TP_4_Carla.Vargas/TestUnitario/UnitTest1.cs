﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Entidades;
using System.Collections.Generic;

namespace TestUnitario
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void VerificarInstanciaListaDePaquetes()
        {
            Paquete p1 = new Paquete("Paquete Uno", "0123456789");
            Paquete p2 = new Paquete("Paquete Dos", "1123456789");

            Paquete p3 = new Paquete("Paquete tres", "0123456789");//No tiene que agregarse
            Paquete p4 = new Paquete("Paquete Cuatro", "4123456789");

            Correo c = new Correo();
            c += p1;
            c += p2;
            try
            {
                c += p3;
            }
            catch (Exception)
            {

                Console.Write("nope") ;
            }
           
            c += p4;
            Assert.IsInstanceOfType(c.Paquetes, typeof(List<Paquete>));
            Assert.IsNotNull(c.Paquetes);
          
        }

        [TestMethod]
        public void VerificarTrackingIdRepetido()
        {
            Paquete p1 = new Paquete("Paquete Uno", "0123456789");
            Paquete p2 = new Paquete("Paquete Dos", "1123456789");

            Paquete p3 = new Paquete("Paquete tres", "0123456789");//No tiene que agregarse
            Paquete p4 = new Paquete("Paquete Cuatro", "4123456789");

            Correo c = new Correo();
           
            try
            {
                c += p1;
                c += p2;
                c += p3;
                c += p4;
            }
            catch (TrackingRepetidoException ex)
            {

                Console.Write(ex.Message);
            }
            Assert.IsTrue(c==p3);      
        }
    }
}
